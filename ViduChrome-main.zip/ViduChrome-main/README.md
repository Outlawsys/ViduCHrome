# ViduCHrome
PoC Vidulum wallet Chrome extension
Simple "Hello world" Chrome extension using the Vidulum non-custodial cryptocurrency wallet.
Proof of Concept. Proof I need a vacation.
NOT developed by the Vidulum team!
